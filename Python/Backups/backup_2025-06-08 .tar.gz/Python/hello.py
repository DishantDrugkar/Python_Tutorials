print('Hello World !')



# Repeatation Rules in Python


# String and numeric values can operate together with *

a,b = 2,3
Txt = "@"
print(2*Txt*4)

# String and String can operate with +

c , d = "2", 3
Str = "@"
print((c+Str) * d)
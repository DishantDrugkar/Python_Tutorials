list = ["Tokyo", "Osaka", "Kyoto", "Shibuya", "Shinjunku", "Akihabara"]

for city in list :
    print(city)


Str = "Dishant"

for char in Str:
    print(char)
   
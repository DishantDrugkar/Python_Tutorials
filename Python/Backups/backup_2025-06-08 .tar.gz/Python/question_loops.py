nums = [3,6,9,12,15,18,21]

idx = 0
while idx < len(nums) :
    print(nums[idx])
    idx += 1
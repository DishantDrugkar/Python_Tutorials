# Taking input from the user

name = input("name : " )

age = int(input("age : "))

print("Hii i am " , name , "and I am " , age , "years old.")
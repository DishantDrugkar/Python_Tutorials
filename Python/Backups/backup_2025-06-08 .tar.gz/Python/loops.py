# Loops in Python

count = 1
while count <= 5 :
    print("Hello World")
    count += 1

print(count)

i = 0
while i <= 5 :
    print(i)
    i += 1
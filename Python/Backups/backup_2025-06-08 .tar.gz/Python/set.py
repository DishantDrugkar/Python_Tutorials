collection = {1,2,3,4,5,5}
print(collection)


# How to Create a Empty set

empty = {}   # This is a dictionary
print(type(empty))

empty_set = set()  # This is an set
print(type(empty_set))
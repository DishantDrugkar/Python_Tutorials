list = [4,5,1,2,3]
list.append(7)
list.sort(reverse = True)
print(list)
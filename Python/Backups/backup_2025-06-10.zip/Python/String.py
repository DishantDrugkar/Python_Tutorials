str1 = "Hello"
str2 = "World !!"
str = str1 + " " + str2
print(str)
print(len(str))  # returns a length

print(str1.capitalize()) # capitalize 1st char

print(str1.replace("Hello", "Hii"))

print(str2.find("World !!"))

print(str1.count("H"))


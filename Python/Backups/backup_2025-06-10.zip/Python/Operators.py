# Arithmetic Operators

a = 5
b = 2

print(a + b)
print(a - b)
print(a * b)
print(a / b)
print(a % b)
print(a ** b) # a^b